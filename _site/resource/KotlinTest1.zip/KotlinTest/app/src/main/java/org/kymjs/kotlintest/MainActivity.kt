package org.kymjs.kotlintest

import android.app.Activity
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatEditText
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import org.kymjs.kjframe.KJActivity
import org.kymjs.kjframe.KJHttp
import org.kymjs.kjframe.http.HttpCallBack
import org.kymjs.kjframe.http.HttpParams
import org.kymjs.kjframe.utils.KJLoger
import org.kymjs.kjframe.utils.StringUtils
import org.kymjs.kjframe.widget.RoundImageView

/**
 * 主界面
 *
 * @author kymjs (https://www.kymjs.com/)
 */
public class MainActivity : KJActivity() {

    var mImgHead: RoundImageView? = null
    var mEtUserName: AppCompatEditText? = null
    var mImgUserDel: ImageView? = null
    var mEtPassWord: AppCompatEditText? = null
    var mImgPwdDel: ImageView? = null
    var mBtnLogin: AppCompatButton? = null

    val kjh: KJHttp = KJHttp()

    override fun setRootView() {
        setContentView(R.layout.activity_login)
    }

    override fun initWidget() {
        mImgHead = bindView(R.id.login_img_avatar)
        mEtUserName = bindView(R.id.login_et_email)
        mImgUserDel = bindView(R.id.login_img_email_delete)
        mEtPassWord = bindView(R.id.login_et_password)
        mImgPwdDel = bindView(R.id.login_img_pwd_delete)
        mBtnLogin = bindView(R.id.login_btn)

        mBtnLogin?.setOnClickListener { v: View ->
            doLogin()
        }

        mImgUserDel?.setOnClickListener { v: View ->
            mEtUserName!!.setText(null)
        }

        mImgPwdDel?.setOnClickListener { v: View ->
            mEtUserName!!.setText(null)
            mEtPassWord!!.setText(null)
        }

        hello()
    }

    fun doLogin() {
        val account: String? = mEtUserName!!.getText().toString();
        val pwd: String? = mEtPassWord!!.getText().toString();

        if (StringUtils.isEmpty(account) || StringUtils.isEmpty(pwd)) {
            toast("用户名或密码不能为空")
            return
        }

        val params: HttpParams = HttpParams()
        params.put("username", account)
        params.put("pwd", pwd)
        kjh.post("http://www.oschina.net/action/api/login_validate", params, CallBack())
    }

    public class CallBack : HttpCallBack() {
        override fun onSuccess(s: String) {
            KJLoger.debug("网络请求成功，$s")
        }

        override fun onFailure(code: Int, msg: String) {
            KJLoger.debug("网络请求失败，$msg")
        }
    }

    fun Activity.toast(message: CharSequence, duration: Int = Toast.LENGTH_SHORT) {
        Toast.makeText(this, message, duration).show()
    }

    fun hello() {
        for (x in 1..5) {
            Log.i("kymjs", "$x")
        }
    }
}
